function [ angle_sig,features ] = HGD( Iout )


% This function compute the HGD indicatior of  an image (Homogenized
% filter). The features is extracted from this indicator.


% Compute the the gradient magnitude and angle (radian) of an image
    [Ixx,Iyy] = gradient(Iout);
    gradient_magnitude_mat = sqrt (abs(Ixx.^2 + Iyy.^2));
    angle_mat  = angle (Ixx+Iyy*i);

% Define 2 threshold to have the pure signal
    threshold1 = find (gradient_magnitude_mat < 6);
    angle_mat (threshold1) = 1000;
    angle_sig = mat2sig (angle_mat);
    threshold2 = find (angle_sig == 1000);
    angle_sig (threshold2) = [];
%     figure (), hist (angle_sig,1000);
%     ylim ([0 100]);
%     set(gca,'ytick',[])
    histogram_angle_sig = smooth (hist (angle_sig,1000),20);
    
% Find the max and min valuss in a signal
    max_val = max (histogram_angle_sig);
    min_val = min (histogram_angle_sig);
    max_min_val = max_val - min_val;
    
% Apply integrator filter
    L1 = 50;
    histogram_angle_sig_fil = integrador (histogram_angle_sig, L1);
%     hog_cell {j} = histogram_angle_sig_fil;
    
% Compute the energy of filtered histogram signal
    histogram_angle_sig_energy = trapz (histogram_angle_sig_fil);
    
% Find the peaks in the filtered histogtam signal
    delta = 0.25;
    max_histogram_angle_sig_fil = peakdet (histogram_angle_sig_fil, delta*max(histogram_angle_sig_fil));

    max_empty = isempty (max_histogram_angle_sig_fil);
    if max_empty  == 1
        peak_number = 0;
        features (1,1) = mean (histogram_angle_sig) / 100;
    end
%     figure (),
%     plot (histogram_angle_sig), hold on, plot (max_histogram_angle_sig(:,1), max_histogram_angle_sig(:,2), 'r*');
%     ylim ([0 100]);

    if max_empty == 0
        peak_loc = max_histogram_angle_sig_fil (:,1)';
        peak_val = max_histogram_angle_sig_fil (:,2)';

% Find the start and end point of each peak
        peak_number = numel (peak_val);
        for k2 = 1:peak_number
            loc = peak_loc (k2);
            w1 = loc - 150;
            if w1 <= 0
                w1 = 1;
            end
            str_val =  histogram_angle_sig_fil (w1:loc);
            srt_ind = w1:loc;
            sp = knnsearch (str_val',0);

            w2 = loc + 150;
            if w2 >= length (histogram_angle_sig_fil)
             w2 = length (histogram_angle_sig_fil);
            end
            end_val = histogram_angle_sig_fil (loc:w2);
            end_ind = loc:w2;
            ep = knnsearch (end_val',0);

            start_point_vector (k2) = srt_ind (sp);
            end_point_vector (k2) = end_ind (ep);
        end

% Campute the energy of each peak (area under each peak)
        peak_width = [];
        peak_energy_sum = 0;
        for  k3 = 1:peak_number
            start_point  = start_point_vector (k3);
            end_point = end_point_vector (k3);
            peak_width {k3} = (histogram_angle_sig_fil (start_point:end_point));
            peak_energy (k3) = trapz (peak_width {k3}); 
            peak_energy_sum = peak_energy_sum + peak_energy (k3);
        end
    end

% Extracted features 
    features (1,1) = peak_energy_sum / histogram_angle_sig_energy;
    features (1,2) = max_min_val;
    features (1,3) = min_val;
    features (1,4) = histogram_angle_sig_energy;

end

