function y=der_lag(x)

B=[1 0 0 0 0 0 -1 0 -1 0 0 0 0 0 1];
A=[1 -1];

y = filter(B,A,x);
y=y(7:length(y));