function pth0 = cath_det(s0, hwin)


%s = filtbyfft(s0-mean(s0),fs, [0.5 250]);
s=s0;
N=length(s);

%fratio = fs/250; % Frequence ratio w.r.t. 250hz.

%hwin=ceil(5*fratio); % half window width for parabolic fitting
weights=1:(-1/hwin):(1/hwin); % parabolic fitting weights in half window
dsw = sqrt([fliplr(weights), 1, weights])'; % square root of double side weights

ps2 = zeros(size(s));
ps0 = zeros(size(s));

xw = [-[(-hwin:hwin).^2]', ones(2*hwin+1,1)];
xw = dsw(:,[1 1]) .* xw;

invxw = inv(xw'*xw)*xw';
for k=(hwin+1):(N-hwin)
  yw = s((k-hwin):(k+hwin));
  yw = dsw .* yw;
  
  %th = xw\yw;
  th = invxw*yw;
  
  ps2(k) = th(1);
  ps0(k) = th(2);
end
pth = ps2.*ps0;
% END of indicator signal computation

% R location
%---------------
PTc = zeros(N,1);
kpt = 0;

pth0 = pth; % Store original pth for missed peaks recovery

