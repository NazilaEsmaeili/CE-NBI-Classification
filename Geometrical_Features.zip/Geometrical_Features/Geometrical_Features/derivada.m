function y = derivada (x)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

B = [2 1 0 -1 -2];
A = 1;
y = filtfilt (B,A,x);
end

