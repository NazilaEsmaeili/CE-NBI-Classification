function s=mat2sig(X)

[n,m]=size(X);
s=[];

for k=1:n
    x=X(k,:);
    if mod(k,2)==0
        %par
        s=[s fliplr(x)];
    else
        %impar
        s=[s x];
    end
end