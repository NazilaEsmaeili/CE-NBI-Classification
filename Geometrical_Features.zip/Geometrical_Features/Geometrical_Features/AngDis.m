function [ angle_vector, distance_vector, features ] = AngDis( S )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

%Find the the objects inside the image
    BO = {};
    [BO]= bwboundaries(S);
    skl_img_size = size (S);
    len_boundary = length(BO);

% Compute the Angle and Diatance indicators
%Define the reference points
    ref_1 = [0,0];
    ref_2 = [0,skl_img_size(1,2)];
    ref_3 = [skl_img_size(1,1),0];
    ref_4 = [skl_img_size(1,2),skl_img_size(1,1)];

% Compute the distance and angle between the reference point and each pixel in each object
    dis1 = [];
    ang1 = [];
    distance = {};
    angle = {};
    for k1 = 1:len_boundary
     boundary = BO {k1};
        p = length (boundary);
        if p >= 50
        for t = 1:p
                dis1 (t) = sqrt ((boundary (t,2) - ref_1 (1,2))^2 + (boundary (t,1) - ref_1(1,1))^2);
                A1 = ref_1;
                B1 = ref_2;
                C1 = boundary;
                AB1 = B1 - A1;
                AC1 (t,:) = C1 (t,:) - A1;
                ang1 (t) = atan2(abs(det([AB1;AC1(t,:)])),dot(AB1,AC1(t,:)));
        end
        end
        distance {k1} = dis1;
        angle {k1} = ang1;
        dis1 = [];
        ang1 = [];
    end

% Remove the empty cells
    angle = angle(~cellfun('isempty',angle));
    distance = distance(~cellfun('isempty',distance));
    
% Concatenate the angle cell to one vector
    angle_vector = [];
    if length (angle) == 1
        angle_vector = angle {1};
    end
    if length (angle) >= 2
        v1 = angle {1};
        for k2 = 2:length (angle)
            v2 = angle {k2};
            v1 = [v1, v2];
            angle_vector = v1;
            v2 = [];
        end
    end
%     angle_ind {j} = angle_vector;
%     figure (), plot (angle_vector);
%     set(gca,'xtick',[]);
%     ylim ([0 1.6]);
    
% Concatenate the distance cell to one vector
    distance_vector = [];
    if length (distance) == 1
        distance_vector = distance {1};
    end
    if length (distance) >= 2
        v3 = distance {1};
        for k2 = 2:length (distance)
            v4 = distance {k2};
            v3 = [v3, v4];
            distance_vector = v3;
            v4 = [];
        end
    end
%     distance_ind {j} = distance_vector;
%     figure (), plot (distance_vector);
%     set(gca,'xtick',[]);
%     ylim ([0 350]);

% Angle: Compute the derivation the of each object in one image
    size_angle = size (angle);
    ang_vec = [];
    derivation_ang = [];
    angle_derivation = {};
    for c1 = 1:size_angle (1,2)
        ang_vec = angle {c1};
        derivation_ang = derivada(ang_vec(10:length(ang_vec)-10));
        angle_derivation {c1} = derivation_ang;
        ang_vec = [];
        derivation_ang = [];
    end
    
% Angle: Define the the threshold for the derivation of each object in one image
    ang_vec_deri = [];
    angle_derivation_th = {};
    for c1 = 1:size_angle (1,2)
        ang_vec_deri = angle_derivation {c1};
        threshold1_ang = find (abs(ang_vec_deri) < 0.1);
        ang_vec_deri (threshold1_ang) = 0;
        threshold2_ang = find (ang_vec_deri > 0.1);
        threshold3_ang = find (ang_vec_deri < -0.1);
        ang_vec_deri (threshold2_ang) = 1;
        ang_vec_deri (threshold3_ang) = 0;
        angle_derivation_th {c1} = ang_vec_deri;
    end
    
% Angle: Compute the number of change of sign of derivation for each object in one image
    ang_vec_sign = [];
    angle_change_sign = [];
    for c1 = 1:size_angle (1,2)
        ang_vec_sign = angle_derivation_th {c1};
        sign_cha_ang_vec_num = numel (find(ang_vec_sign == 1));
        angle_change_sign (c1,:) = sign_cha_ang_vec_num;
        ang_vec_sign = [];
    end
    
% Distance: Compute the derivation the of each object in one image
    size_distance = size (distance);
    dis_vec = [];
    derivation_dis = [];
    distance_derivation = {};
    for c1 = 1:size_distance (1,2)
        dis_vec = distance {c1};
        derivation_dis = derivada(dis_vec(10:length(dis_vec)-10));
        distance_derivation {c1} = derivation_dis;
        dis_vec = [];
        derivation_dis = [];
    end
    
% Distance: Define the threshold for the derivation of each object in one image
    dis_vec_deri = [];
    distance_derivation_th = {};
    for c1 = 1:size_distance (1,2)
        dis_vec_deri = distance_derivation {c1};
        threshold1_dis = find (abs(dis_vec_deri) < 10);
        dis_vec_deri (threshold1_dis) = 0;
        threshold2_dis = find (dis_vec_deri > 10);
        threshold3_dis = find (dis_vec_deri < -10);
        dis_vec_deri (threshold2_dis) = 1;
        dis_vec_deri (threshold3_dis) = 0;
        distance_derivation_th {c1} = dis_vec_deri;
    end
    
% Distance: Compute the number of change of sign of derivation for each object in one image
    dis_vec_sign = [];
    distance_change_sign = [];
    for c1 = 1:size_distance (1,2)
        dis_vec_sign = distance_derivation_th {c1};
        sign_cha_dis_vec_num = numel (find(dis_vec_sign == 1));
        distance_change_sign (c1,:) = sign_cha_dis_vec_num;
        dis_vec_sign = [];
    end
    
% Compute the mean, max, median and sum over the change of number of sign
    mean_sign_angle = mean (angle_change_sign);
    mean_sign_distance = mean (distance_change_sign);
    max_sign_angle = max (angle_change_sign);
    max_sign_distance = max (distance_change_sign);
    sum_sign_angle = sum (angle_change_sign);
    sum_sign_distance = sum (distance_change_sign);
    median_sign_angle = median (angle_change_sign);
    median_sign_distance = median (distance_change_sign);
    
%Angle: Compute the polynomial fitted to each object and compute the error 
    ang_vec = [];
    x_ang = [];
    y_ang = [];
    P_ang = [];
    for c1 = 1:size_angle (1,2)
        ang_vec = angle {c1};
        x_ang = linspace (1,length(ang_vec),length(ang_vec));
        degree_ang = 2;
        [P_ang,S_ang] = polyfit(x_ang,ang_vec,degree_ang);
        [y_ang,delta_ang] = polyval(P_ang,x_ang,S_ang);
        error_ang (c1,:) = immse(ang_vec,y_ang);
        sub_ang = ang_vec - y_ang;
%         figure(), plot (ang_vec, 'b'), hold on, plot (y_ang, 'r'), hold on, plot (sub_ang, 'g'), hold off;
%         legend('real data','polynomial fit', 'difference');
%         title ('Angle');
%         ylim ([-1 1.7]);
        ang_vec = [];
        x_ang = [];
        y_ang = [];
        P_ang = [];
    end
    mean_error_angle = mean (error_ang);
    median_error_angle = median (error_ang);
    
%Distance: Compute the polynomial fitted to each object and compute the error 
    dis_vec = [];
    x_dis = [];
    y_dis = [];
    P_dis = [];
    for c1 = 1:size_distance (1,2)
        dis_vec = distance {c1};
        x_dis = linspace (1,length(dis_vec),length(dis_vec));
        degree_dis = 2;
        [P_dis,S_dis] = polyfit(x_dis,dis_vec,degree_dis);
        [y_dis,delta_dis] = polyval(P_dis,x_dis,S_dis);
        error_dis (c1,:) = immse(dis_vec,y_dis);
        sub_dis = dis_vec - y_dis;
%         figure(), plot (dis_vec, 'b'), hold on, plot (y_dis, 'r'), hold on, plot (sub_dis, 'g'), hold off;
%         legend('real data','polynomial fit', 'difference');
%         title ('Distance');
%         ylim ([-8 25]);
        dis_vec = [];
        x_dis = [];
        y_dis = [];
        P_dis = [];
    end
 
% Compute the mean and midian of error
    mean_error_angle = mean (error_ang);
    median_error_angle = median (error_ang);
    mean_error_distance = mean (error_dis);
    median_error_distance = median (error_dis);
 
% Extracted features  
    features (1,1) = mean_sign_angle;
    features (1,2) = mean_sign_distance;
    features (1,3) = max_sign_angle;
    features (1,4) = max_sign_distance;
    features (1,5) = sum_sign_angle;
    features (1,6) = sum_sign_distance;
    features (1,7) = median_sign_angle;
    features (1,8) = median_sign_distance;
    features (1,9) = mean_error_angle;
    features (1,10) = mean_error_distance;
    features (1,11) = median_error_angle;
    features (1,12) = median_error_distance;
end

