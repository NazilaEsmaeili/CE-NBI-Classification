function [ curvature_vec, features ] = CURVE( S )


% This function exract centerlin of the vessel and estimate the the level
% of curverture of each vessel using "Curvature Estimation" function. Then 
% it extacts the features from curvature indicators.


%Find the the objects inside the image
    BO = {};
    [BO]= bwboundaries(S);
    len_BO = length(BO);

% Curvature Estimation
% Estimate the curverture of each object (vessel) in one image
    curvture_array = {};
    for k1 = 1:len_BO
        boundary = BO {k1};
        boundary = boundary (6:length(boundary)-5,:);
        p1 = length (boundary);
        if p1 >= 50
            fn = 8;
            bn = 8;
            [curve,ang] = CurvatureEstimation(boundary, fn, bn);
            length_curve = length (curve);
            curvture_array{k1} = curve(10:length_curve-10) ;
        end
    end
    curvture_array = curvture_array(~any(cellfun('isempty', curvture_array), 1));
    len_curvature_array = length (curvture_array);

% Concatenate all the objects of one image to one vector
    curvature_vec = [];
    if len_curvature_array == 1
        curvature_vec = curvture_array {1}.';
    end
    if len_curvature_array >=2
        v1 = curvture_array {1};
        for k2 = 2:len_curvature_array
            v2 = curvture_array {k2};
            v1 = [v1; v2];
            curvature_vec = v1.';
        end
    end
    nan_coordinate = find(isnan(curvature_vec));
    curvature_vec (nan_coordinate) = 0;
%     curve_estimation {j} = curvature_vec;
%     figure (), plot  (curvature_vec);
%     set(gca,'xtick',[]);
%     ylim ([0 0.45]);

% Find the energy of each curvature vector 
    curvature_vec_energy = trapz (curvature_vec);
    
% Compute the varience
    curvature_vec_var = var (curvature_vec);
    
% Find the peaks of the signal, plot them (Find the impulses of the signal) 
    delta = 0.1;
    max_curvature_vec = peakdet (curvature_vec, delta);
    condition = isempty (max_curvature_vec);
    if condition == 1
        peak_loc = [];
        peak_val = [];
        number_peaks = 0;
        multi_mean = 0;
%         figure (); 
%         plot(curvature_vec);
%         ylim ([0 0.5]); 
    else
        peak_loc = max_curvature_vec (:,1)';
        peak_val = max_curvature_vec (:,2)';
%         figure (),
%         plot (curvature_vec), hold on, plot (max_curvature_vec(:,1), max_curvature_vec(:,2), 'r*');
%         ylim ([0 0.5]); 

% Compute the mean, sum and number of peak values and the  multiplication
        mean_amplitude = mean (peak_val);
        sum_amplitude = sum (peak_val);
        number_peaks = numel (peak_val);
        multi_sum = sum_amplitude*number_peaks;
        multi_mean = mean_amplitude*number_peaks;
    end

% Extracted features
    features (1,1) = curvature_vec_energy;
    features (1,2) = curvature_vec_var;
    features (1,3) = number_peaks;
    features (1,4) = multi_mean;


end

