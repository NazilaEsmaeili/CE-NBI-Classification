function [mean_sig_fil, features] = RIA ( If )


% This program compute the average of the an image (filterd by Frangi filter)
% in different angle. The average used as an indicator and the features is
% extracted from it.


% Rotate the image every 20 degree, compute the mean profile in each angle 
% and put them in a matrix
    g = 1;
    for k1 = 0:20:180
        I_rotate = imrotate (If, k1, 'crop');
        mean_I_rotate = mean (I_rotate);
        mean_mat (g,:) = mean_I_rotate;
        g = g + 1;
    end
%     figure (), imagesc (mean_mat);
%     set(gca,'xtick',[]);
%     figure (), plot (mat2sig (mean_mat));
%     set(gca,'xtick',[]);
%     ylim ([2.8 3.5]);
% Concatenate the average matrix and put a filter on it
    mean_sig = mat2sig (mean_mat);
    mean_sig_cath = cath_det (mean_sig,3);
    mean_sig_fil = integrador(mean_sig_cath, 10);
%     mean_ave_cell {j} = mean_sig_fil;
    
% Compute the energy of the filtered average signal
    mean_sig_fil_energy = trapz (mean_sig_fil);

% Find the peaks of the signal, plot them (Find the impulses of the signal) 
    delta = 0.25;
    max_mean_sig_fil = peakdet (mean_sig_fil, delta*max(mean_sig_fil));
    peak_loc = max_mean_sig_fil (:,1)';
    peak_val = max_mean_sig_fil (:,2)';
    mean_sig_fil_deri = der_lag (mean_sig_fil);
%     figure (),
%     plot (mean_sig_fil), hold on, plot (max_mean_sig_fil(:,1), max_mean_sig_fil(:,2), 'r*');

% Find the start and end point of each peak
    peak_number = numel (peak_val);
    for k2 = 1:peak_number
        loc = peak_loc (k2);
        w1 = loc - 20;
        if w1 <= 0
            w1 = 1;
        end
        str_val =  mean_sig_fil (w1:loc);
        srt_ind = w1:loc;
        sp = knnsearch (str_val',0);

        w2 = loc + 20;
        if w2 >= length (mean_sig_fil)
            w2 = length (mean_sig_fil);
        end
        end_val = mean_sig_fil (loc:w2);
        end_ind = loc:w2;
        ep = knnsearch (end_val',0);
        start_point_vector (k2) = srt_ind (sp);
        end_point_vector (k2) = end_ind (ep);
    end

% Campute the energy of each peak (area under each peak) and compute
% features
    peak_width = {};
    peak_energy_sum = 0;
    peak_amp_dis_sum = 0;
    for  k3 = 1:peak_number
        start_point  = start_point_vector (k3);
        end_point = end_point_vector (k3);
        peak_width {k3} = (mean_sig_cath (start_point:end_point));
        peak_energy (k3) = trapz (peak_width {k3});
        peak_energy_mean = mean (peak_energy);
        width = end_point - start_point;
        value = peak_val (k3);
        peak_amp_dis (k3) = value / width; 
        peak_amp_dis_mean = mean (peak_amp_dis);
    end

% Extracted features
    features (1,1) = mean_sig_fil_energy;
    features (1,2) = peak_number;
    features (1,3) = peak_energy_mean / mean_sig_fil_energy;
    features (1,4) = peak_amp_dis_mean ;  
end

