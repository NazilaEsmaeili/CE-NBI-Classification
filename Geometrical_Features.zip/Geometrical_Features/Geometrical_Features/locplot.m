function locplot(s, fs, loc1, loc2, loc3)
%LOCPLOT location plot: plot a signal with time location marks 
%LOCPLOT(S, FS, LOC) with the signal S vector S, sampling frequency FS 
%and vector of locations LOC
%LOCPLOT(S, FS, LOC1, LOC2, LOC3) for up to 3 different types of location
%markers, corresponding to red solid lines, dashed blue lines and dotted
%green line
%
% Author: Qinghua Zhang
% Copyright 2005 INRIA

nin = nargin;
if nargin<3
  error('Too few input arguments')
end

s = s(:);
loc1 = loc1(:);
xv = (1:length(s))'/fs;

clf
plot(xv,s, '-k');
ym = ylim;
hold on
plot(loc1(:, [1 1])'/fs, ym(ones(length(loc1),1),:)','-g')

if nin>3
  plot(loc2(:, [1 1])'/fs, ym(ones(length(loc2),1),:)','--r')
end

if nin>4
  plot(loc3(:, [1 1])'/fs, ym(ones(length(loc3),1),:)',':b')
end

hold off