function [areatab] = peakarea(v,p,w)

% This function gets a vector, pick of the vector, the lengh of window,
% and then calculates the integral of each pick and retures the sum of 
% integrals.

% counting the number of picks
number_pick = numel (p(:,2));

areatab = 0;

%for each pick calculate the integral and add them to each other.
for i=1 : number_pick
    w1 = p (i,1)- w;
    w2 = p (i,1)+ w;
    
    if w1 <= 0
        w1 = 1;
    end
        
    t = trapz (v(w1:w2));
    areatab = areatab + t;
end

end

