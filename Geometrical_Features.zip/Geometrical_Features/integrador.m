function [y] = integrador(x,L)

noverlap = L-1;
N = length(x);
nfft = L;
incr  =  nfft-noverlap;

x_mod  =  [x];
j = 1;

for i  =  1:incr:N-nfft+1
    data  =  x_mod (i:i+nfft-1);
%     y(j) = sum(data.^2);
    y(j)= sum(data);
    j = j+1;
end

