function [IvesselFrangi,BW2morph] = main(I1)
% clear all; close all; clc;
% I1 -> input image
% IvesselFrangi -> o/p image after frangi vessel filter
% BW2morph -> o/p image after morphological operations
% I1 = imread('.\images\endo - orig.png');

if(size(I1,3) ==3) I1 = rgb2gray(I1); end;
%figure, imshow(I1);

% apply median filter incase if there was speckle noise
 I1 =  medfilt2(I1);
 
 
IvesselFrangi=mat2gray(FrangiFilter2D(mat2gray(I1)));
%figure, imshow(IvesselFrangi);

canny = edge(IvesselFrangi,'canny');
%figure, imshow(canny);

BW2morph = bwmorph(canny,'thicken');
BW2morph = imfill(bwmorph(BW2morph,'close'),'holes');
BW2morph = bwmorph(BW2morph,'thicken');
BW2morph = bwmorph(BW2morph,'open');
BW2morph = bwmorph(BW2morph,'bridge');
BW2morph = imfill(bwmorph(BW2morph,'bridge'),'holes');

%figure, imshow(BW2morph);



%% incase if you want to remove some small unconnected binary components

CC = bwconncomp(BW2morph);
numPixels = cellfun(@numel,CC.PixelIdxList);
[biggest,idx] = max(numPixels);
BW2morph = zeros(size(BW2morph));
BW2morph(CC.PixelIdxList{idx}) = 1;
% figure
% imshow(BW2morph);

end

