clear all;
close all;
clc;

input_folder = './images2';
inp_imageNames = dir(fullfile(input_folder, '*.jpg'));
inp_images = {inp_imageNames.name}';
total_images = length(inp_images);

%decide which images do you want to work on
iteration_start = 1;
iteration_end = 3;

for j = iteration_start:iteration_end
    inp = strcat('./images2/', inp_images{j});  
    I = imread(inp);  
    I = double(rgb2gray(I));
    I2 = imresize(I,1/5);
    
% Image pre_processing
    [n,m] = size(I2);
    nivel = 7;

    for k = 1:n
        x = I2(k,:);
        [A,D] = extdinamicas(x,nivel,'db4');
        Iw(k,:) = sum(D');
        A = [];
        D = [];
    end

    for k = 1:m
        x = I2(:,k);
        [A,D] = extdinamicas(x,nivel,'db4');
        Iw2(:,k) = sum(D')';
        A = [];
        D = [];
    end

    Iout = Iw + Iw2;
%     Izero = Iout;
%     a = find(Iout>0);
%     Izero(a) = 0;
%     s = mat2sig(Iout);
%     s = sort(s,'descend');
%     L = s(round(0.95*length(s)));
%     Ibin = Izero;
%     a1 = find(Ibin>L);
%     Ibin(a1) = 0;
%     a2 = find(Ibin<=L);
%     Ibin(a2) = 1;

    [If,Im] = main(Iout);
%     figure (), imagesc (Iout);
%     set(gca,'xtick',[]);
%     set(gca,'ytick',[]);
    figure (), imagesc (If)
    set(gca,'xtick',[]);
    set(gca,'ytick',[]);

% Binarized the image
    level = graythresh(If);
    I3 = im2bw (If, level*0.45);

% image skeletonization 
    S = bwmorph (I3, 'skel', Inf);
%     figure (), imshow (S);
%     set(gca,'xtick',[]);
%     set(gca,'ytick',[]);
    
end