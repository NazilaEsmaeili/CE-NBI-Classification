import os
import time
import numpy as np
import pandas as pd
import tensorflow as tf
import tensorflow.compat.v1 as tf1
#tf.disable_v2_behavior()
#tf.compat.v1.disable_eager_execution()
from tensorflow.python.framework.ops import disable_eager_execution
import tensorflow.keras
disable_eager_execution()
#print("****tf.executing_eagerly()****", tf.executing_eagerly())
from tensorflow.keras import backend as K
#from keras_preprocessing.image import ImageDataGenerator #with tf-cpu1.13.1 
from tensorflow.keras.preprocessing.image import ImageDataGenerator
#from tensorflow_core.python.keras.api._v2.keras  import models
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Input, AveragePooling2D
from tensorflow.keras.layers import Activation, Dropout, Flatten, Dense, GlobalAveragePooling2D, GlobalMaxPool2D,MaxPooling2D, AveragePooling2D, BatchNormalization
from tensorflow.keras import optimizers
from tensorflow.keras import applications
from tensorflow.keras.applications.resnet50 import ResNet50, preprocess_input
from tensorflow.keras.models import load_model
from tensorflow.keras.callbacks import Callback, TensorBoard, ModelCheckpoint, EarlyStopping
from pathlib import Path, PureWindowsPath
from sklearn.model_selection import StratifiedKFold
import gc
import statistics

from Model_Evaluation import model_evaluation
from exclude_indx_for_testing import data_4_training_testing_with_unseen_data

def simpleCNN(batch_size, img_width, img_height, img_depth, classifer_activation_func):
    #regularizer = tf.keras.regularizers.L1L2(0.001, 0.001)
    model = Sequential()
    model.add(Conv2D(16, kernel_size=(3, 3), activation='relu', input_shape=(img_height, img_width, img_depth)))  #, kernel_regularizer=regularizer))
    model.add(Conv2D(32, (3, 3), activation='relu'))    #, kernel_regularizer=regularizer))
    model.add(Conv2D(64, (3, 3), activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    #model.add(Conv2D(64, kernel_size=(3, 3), activation='relu'))    #, kernel_regularizer=regularizer))
    #model.add(Conv2D(64, (3, 3), activation='relu'))        #, kernel_regularizer=regularizer))
    #model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(BatchNormalization(momentum=0.9, trainable=True))
    # model.add(Flatten())
    #model.add(Dropout(0.4))
    model.add(GlobalMaxPool2D())
    # model.add(Dropout(0.5))
    # model.add(Dense(10, activation='relu'))     #, activity_regularizer=regularizer))
    model.add(Dense(2-1, activation=classifer_activation_func))
    return model

def make_image(tensor):       # Image visualization on TensorBoard
    """
     Convert an numpy representation image to Image protobuf.
     Copied from https://github.com/lanpa/tensorboard-pytorch/
    """
    from PIL import Image
    height, width, channel = tensor.shape
    image = Image.fromarray(tensor)
    import io
    output = io.BytesIO()
    image.save(output, format='PNG')
    image_string = output.getvalue()
    output.close()
    return tf1.Summary.Image(height=height,
                        width=width,
                        colorspace=channel,
                        encoded_image_string=image_string)

# Class for checking Augmented images on Tensorboard
class TensorBoardImage(tf.keras.callbacks.Callback):
    def __init__(self, val_imgs, tag):
        super().__init__()
        self.validation_imgs = val_imgs
        self.tag = tag

    def on_epoch_end(self, epoch, logs={}):
        # Load image
        img = self.validation_imgs[0][0][0]
        img = (255 * img).astype('uint8')
        # Do something to the image
        image = make_image(img)
        summary = tf1.Summary(value=[tf1.Summary.Value(tag=self.tag, image=image)])
        writer = tf1.summary.FileWriter('./logs')
        writer.add_summary(summary, epoch)
        writer.close()
        return




print("###################  Executing The Model  ########################")

#### Path Formating owing to Windows OS ####
# Pathlib (trial 1) 
#def training_folder_path_prefix(fn):
#    rootPath = PureWindowsPath("C:\\Users\\AdminUser\\Desktop\\esam_master_work\\CE+NBI_Dataset")
#    workingPath = rootPath / fn
#    return workingPath

#def validation_folder_path_prefix(fn):
#    rootPath = PureWindowsPath("C:\\Users\\AdminUser\\Desktop\\esam_master_work\\CE+NBI_Dataset")
#    workingPath = rootPath / fn
#    return workingPath


# Pathlib (trial 2)
def training_folder_path_prefix(fn):
    rootPath = Path("C:/Users/AdminUser/Desktop/esam_master_work/CE+NBI_Dataset")
    workingPath = rootPath / fn
    #print(type(str(workingPath)))
    return str(workingPath)

def validation_folder_path_prefix(fn):
    rootPath = Path("C:/Users/AdminUser/Desktop/esam_master_work/CE+NBI_Dataset")
    workingPath = rootPath / fn
    return str(workingPath)

def testingDB_folder_path_prefix(fn):
    rootPath = Path("C:/Users/AdminUser/Desktop/esam_master_work/CE+NBI_Dataset_test")
    workingPath = rootPath / fn
    return str(workingPath)


#### Metrics Functions ####
def sensitivity(y_true, y_pred):
    true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
    possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
    sensitivity = true_positives / (possible_positives + K.epsilon())
    return sensitivity

def specificity(y_true, y_pred):
    true_negatives = K.sum(K.round(K.clip((1-y_true) * (1-y_pred), 0, 1)))
    possible_negatives = K.sum(K.round(K.clip(1-y_true, 0, 1)))
    specificity =  true_negatives / (possible_negatives + K.epsilon())
    return specificity

def DSC (y_true, y_pred):       #Dice_Similarity_Coefficient
    true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))   
    possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
    possible_negatives = K.sum(K.round(K.clip(1-y_true, 0, 1)))
    true_negatives = K.sum(K.round(K.clip((1-y_true) * (1-y_pred), 0, 1)))
    false_postives = possible_positives - true_positives
    false_negative = possible_negatives - true_negatives
    DSC = (2*true_positives) / ((2*true_positives) + false_postives + false_negative)
    return DSC


# Exoprting model summary
def export_model_summary(model):
    filename = 'RestNet50_FullStruct_summary'         
    with open(filename + '.txt','w') as fh:
        ## Pass the file handle in as a lambda function to make it callable
        model.summary(print_fn=lambda x: fh.write(x + '\n'))


## Model Parameters
img_width, img_height, img_depth = 224, 224, 3 # width: 284 to keep orginal aspect ratio 
batch_Size = 32    
epochs = 100
folds_num = 5


# Cross-validation and testing lists
fold_mean_val_loss = []
folds_mean_val_loss_list = []
folds_min_val_loss_list = []
folds_max_val_acc_list = []
folds_evaluation_list = []
folds_evaluation_list_unseen_data = []

# Name of Cut-off Layer
cut_off_layer = 'conv2_block3_out'   #'conv3_block4_2_relu' 

# Name of the Layer weights fine-tuning starts
# start_fine_tune_up_at = 'conv2_block1_out'

# Picking out different portion of dataset for testing (after shuffling) -- testing data at this option are censored!
test_2 = False

# Setting-up testing on unseen data from the dataset
testing_on_unseen_data = True


# Reading DB CSV files
df_training = pd.read_csv("./CE+NBI_Dataset/split_bin_df_training.csv")
df_validation = pd.read_csv("./CE+NBI_Dataset/split_bin_df_validation.csv")

# Reading testing DB CSV files
df_training_test = pd.read_csv("./CE+NBI_Dataset_test/split_bin_test_df_training.csv")
df_validation_test = pd.read_csv("./CE+NBI_Dataset_test/split_bin_test_df_validation.csv")

# Applying a function for making up the absolute path format for each input image in training Dataset
df_training["filename"] = df_training["filename"].apply(training_folder_path_prefix)
df_validation["filename"] = df_validation["filename"].apply(validation_folder_path_prefix)

# Applying a function for making up the absolute path format for each input image in testing Dataset
df_training_test["filename"] = df_training_test["filename"].apply(testingDB_folder_path_prefix)
df_validation_test["filename"] = df_validation_test["filename"].apply(testingDB_folder_path_prefix)


# Merging two datasets (training and testing) as whole for the cross validation tech.
if testing_on_unseen_data:
    concat_df_training_df_validation = [df_training, df_validation]
    training_dataset = pd.concat(concat_df_training_df_validation, ignore_index=True)
    concat_df_training_test_df_validation_test = [df_training_test, df_validation_test]
    testing_dataset = pd.concat(concat_df_training_test_df_validation_test, ignore_index=True)
    df_training_dataset_4_unseen_testing, df_testing_dataset_4_unseen_testing, df_unseen_test_data = data_4_training_testing_with_unseen_data(
        df_training, df_training_test, counter = 30) # counter: number of hold-out images (zero value of counter arg. for taking-out pre-selected patients totally) 
    df_frames = [df_training_dataset_4_unseen_testing, df_testing_dataset_4_unseen_testing]
else:
    df_frames = [df_training, df_validation, df_training_test, df_validation_test]

# Concatinating the dataframes
dataset = pd.concat(df_frames, ignore_index=True)

# Shufling the whole 8181 dataset images
shuffled_dataset = dataset.sample(frac=1, random_state=41)

# Checking for duplications in [filename] coloumn, after shuffeling
# dup_elems = shuffled_dataset[shuffled_dataset.duplicated(keep=False)]
# print('dup_elems', dup_elems)


# Extacting the training/testing images portions
if not testing_on_unseen_data:
    shuffled_dataset_training_portion_size = int((shuffled_dataset.shape[0] / folds_num) * (folds_num-1))
    shuffled_dataset_testing_portion_size = int(shuffled_dataset.shape[0] / folds_num)
if not test_2 and not testing_on_unseen_data:
    # Extacting the training images portion
    shuffled_dataset_training_portion = shuffled_dataset[:shuffled_dataset_training_portion_size]
    # Extacting the testing images portion ( this is censored since data shuffling has been done up in the code)
    shuffled_dataset_testing_portion = shuffled_dataset[-1*(shuffled_dataset_testing_portion_size+1):]
elif test_2 and not testing_on_unseen_data:
    # Extacting the training images portion
    shuffled_dataset_training_portion = shuffled_dataset[-1*(shuffled_dataset_training_portion_size+1):]
    # Extacting the testing images portion
    shuffled_dataset_testing_portion = shuffled_dataset[:shuffled_dataset_testing_portion_size]
 

# Cheking any overlapping in indices
if not testing_on_unseen_data:
    overlap_ixs = shuffled_dataset_training_portion.index.intersection(shuffled_dataset_testing_portion.index)
    print ("\n overlap_ixs check", overlap_ixs)
# print('\n shuffled_dataset_training_portion', shuffled_dataset_training_portion)
# print('\n')
# print('\n', shuffled_dataset_training_portion.shape)
# print('\n shuffled_dataset_testing_portion', shuffled_dataset_testing_portion)
# print('\n', shuffled_dataset_testing_portion.shape)


# Splitting the training set into input (X) and truth labels (Y) variables
if testing_on_unseen_data:
    X = shuffled_dataset["filename"]
    Y = shuffled_dataset["lesion"]
else:
    X = shuffled_dataset_training_portion["filename"]
    Y = shuffled_dataset_training_portion["lesion"]

# Setting-up k-fold arguments
kfold = StratifiedKFold(n_splits=folds_num, random_state=42, shuffle=True)

# This loop for cross-validation
for i, (train_idx, valid_idx) in enumerate(kfold.split(X, Y)):
    
    print("\n \n Running Fold", i+1, "\n")
    ## Preparing training & validation data
    if testing_on_unseen_data:      #kfold.split is not considered in this option (no cross-validation will be implemented)
        df_fold_training = shuffled_dataset.iloc[train_idx,:] 
        df_fold_validation = shuffled_dataset.iloc[valid_idx,:]
        print("Training Labels % : \n", df_fold_training["lesion"].value_counts(normalize=True),"\n")
        print("Validation Labels  % : \n", df_fold_validation["lesion"].value_counts(normalize=True),"\n")
        print("Testing Labels  % : \n", df_unseen_test_data["lesion"].value_counts(normalize=True),"\n")
    else:   # Setting up dfs according to the kfold.split
        shuffled_dataset_training_portion.iloc[train_idx,:]                                             #dataset.iloc[train_idx,:]
        shuffled_dataset_training_portion.iloc[valid_idx,:]
        print("Training Labels % : \n", shuffled_dataset_training_portion["lesion"].value_counts(normalize=True),"\n")
        print("Validation  Labels % : \n", shuffled_dataset_training_portion["lesion"].value_counts(normalize=True),"\n")

    # Model Namefor Checkpointing & Tensorboard Logging
    Model_NAME = "get program excution time"    #Res_284x224_{}_AllTuned_GloMaxPool_noDrop_noDense_SGD1e-3_Bat32_erStop7_VeHoAug_f{}.h5".format(cut_off_layer, i+1)

    # setting the LR (must be here inside the loop for getting the script complied)
    # adam =  tf.keras.optimizers.Adam(lr=1e-3)
    sgd = tf.keras.optimizers.SGD(lr=1e-3, momentum=0.9, decay=1e-6, nesterov=True)
    # adagrad = keras.optimizers.Adagrad(lr=0.1, epsilon=None, decay=0.0)
    # rmsprop = keras.optimizers.RMSprop(lr=0.001, rho=0.9, epsilon=None, decay=0.0)
    # tf.keras.optimizers.Adadelta()

    
    # Building Transfer Learning Model
    base_model = ResNet50(weights ="imagenet", include_top=False, input_shape = (img_height, img_width, img_depth))     #Transfer Learning Model
    # model_final = simpleCNN(batch_Size, img_width, img_height, img_depth, 'sigmoid') # simple model


    # Switching trainable attribute of base_model's layers
    # for layer in base_model.layers:
    #     layer.trainable= False

    
    # Selecting the Layer where the Cutt-off
    model = base_model.get_layer(cut_off_layer).output
    
    # Export model suumary as .txt file (once needed)
    #export_model_summary(model)

    # Top Classifer layers - Customized Layers
    # top_model = Dropout(0.3)(model)
    # top_model = GlobalAveragePooling2D()(model)
    # top_model = MaxPooling2D(pool_size=(2, 2))(model)
    top_model = GlobalMaxPool2D()(model)
    # top_model = AveragePooling2D()(model)
    # top_model = Flatten()(top_model)
    
    # top_model = Dropout(0.6)(top_model)
    # top_model = Dense(512, activation="relu")(top_model) #tanh, leaky-Relu activate functiones--try it!
    # top_model = Dropout(0.2)(top_model)
    # top_model = Dense(64, activation="relu")(top_model)
    # top_model = Dropout(0.5)(top_model)
    predictions = Dense(1, activation="sigmoid")(top_model)
    model_final = Model(inputs=base_model.input, outputs=predictions)


    # Setting up some layers as non-trainable layers for feature extraction (for Transfer Learning Model)
    layer_train_attribute = True
    for layer in model_final.layers:
    #     #if layer.name == start_fine_tune_up_at
    #     #    layer_train_attribute = True
        layer.trainable = layer_train_attribute
    #     #if layer.name[-2:] == 'bn':
        #    layer.trainable = True
        # print(layer.name, layer.trainable) #Checking each layer's "trainble" attribute on the terminal


    # Print Model (Feature extractor + Classifier) structure on the Terminal
    model_final.summary()


    # Compiling the Model
    model_final.compile(loss="binary_crossentropy", optimizer= sgd, metrics=['accuracy', sensitivity, specificity, DSC])


    # Rescaling and Data Augmentation
    datagen = ImageDataGenerator(rescale=1./255, rotation_range=90) #horizontal_flip=True, vertical_flip=True)

    valid_datagen = ImageDataGenerator(rescale=1./255) #preprocessing_function=preprocess_input)rescale=1./255


    # Image Generator for Training Phase
    train_generator = datagen.flow_from_dataframe(dataframe=df_fold_training, directory= None,
                                                x_col= "filename", y_col= "lesion",             
                                                class_mode= "other", target_size= (img_height, img_width), batch_size = batch_Size)

    # Image Generator for Validation Phase
    validation_generator = valid_datagen.flow_from_dataframe(dataframe=df_fold_validation, directory= None,
                                                x_col= "filename", y_col= "lesion",
                                                class_mode= "other", target_size= (img_height, img_width), batch_size = batch_Size)


    # Callbacks 
    tensorboard = TensorBoard(log_dir=r"C:\Users\AdminUser\Desktop\esam_master_work\logs\{}".format(Model_NAME), write_graph=True)
    checkpoint = ModelCheckpoint(Model_NAME, monitor='val_accuracy', verbose=1, save_best_only=True,
                                    save_weights_only=False, mode='auto', period=1)  #"weights-improvement-{epoch:02d}-{val_accuracy:.2f}.hdf5"
    Early_Stop = EarlyStopping(monitor='val_loss', min_delta=1e-3, patience=7, 
                                    verbose=1, mode='auto', baseline=None, restore_best_weights=False)
    tbi_callback = TensorBoardImage(train_generator, 'Image Example')

    # # Export model suumary as .txt file (once needed)
    # export_model_summary(model_final)
    start_time = time.time()
    # Fitting the Model into TF session
    with tf.compat.v1.Session() as sess:
        sess.run(tf.compat.v1.global_variables_initializer())
        hist = model_final.fit(
                train_generator,
                steps_per_epoch=df_fold_training.shape[0] // batch_Size,
                epochs=epochs,
                shuffle=True,
                validation_data=validation_generator,
                validation_steps=df_fold_validation.shape[0] // batch_Size,
                callbacks=[tensorboard, checkpoint, Early_Stop, tbi_callback])
        sess.close()

    fold_mean_val_loss = np.mean(hist.history['val_loss']) 
    fold_min_val_loss = np.min(hist.history['val_loss'])  
    fold_max_val_acc = np.max(hist.history['val_accuracy'])
    print("\n fold_mean_val_loss %.4f" % fold_mean_val_loss)
    print("\n fold_min_val_loss %.4f" % fold_min_val_loss)
    print("\n fold_max_val_acc %.4f" % fold_max_val_acc)
    print("\n fold_max_val_acc %.4f" % fold_max_val_acc, '/n')
    
    training_period = time.time() - start_time
    
    ## Evaluate the Model
    
    
    ##Testing Phase
    if testing_on_unseen_data:      # on uncensored data (test images taken out before shuffling the DBs)
        fold_evaluation_unseen_data = model_evaluation (Model_NAME, df_unseen_test_data, img_width, img_height, img_depth)
        folds_evaluation_list_unseen_data.append(fold_evaluation_unseen_data)
        print("\n folds_evaluation_list_unseen_data", folds_evaluation_list_unseen_data)
    else:       # On censored data
        fold_evaluation = model_evaluation (Model_NAME, shuffled_dataset_testing_portion, img_width, img_height, img_depth)
        folds_evaluation_list.append(fold_evaluation)
        print("\n folds_evaluation_list", folds_evaluation_list)
    
    testing_period = time.time() - training_period - start_time             
    
    folds_mean_val_loss_list.append(fold_mean_val_loss)
    folds_min_val_loss_list.append(fold_min_val_loss)
    folds_max_val_acc_list.append(fold_max_val_acc)
    print("\n folds_mean_val_loss_list", folds_mean_val_loss_list)
    print("\n folds_min_val_loss_list", folds_min_val_loss_list)
    print("\n folds_max_val_acc_list", folds_max_val_acc_list)
    

print ("\n Model Summary: ", Model_NAME)
print('\n')
print('%s %.2f' % ('\n 5-fold Mean of (Mean) Validation Losses', statistics.mean(folds_mean_val_loss_list)))           
print('%s %.2f' % ('\n 5-fold Mean of (Min.) Validation Losses', statistics.mean(folds_min_val_loss_list)))
print('%s %.4f' % ('\n 5-fold Mean of (Max.) Validation Accuracies', statistics.mean(folds_max_val_acc_list)))

if(testing_on_unseen_data):
    print("\n folds_evaluation_list_unseen_data", folds_evaluation_list_unseen_data)
else:
    print("\n folds_evaluation_list", folds_evaluation_list)

print("\n training Period: ", training_period)

print("\n testing Period:", testing_period)
