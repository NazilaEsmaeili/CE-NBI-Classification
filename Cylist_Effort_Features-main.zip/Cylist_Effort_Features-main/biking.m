function [f_g, f_r, f_d] = biking(g, G, W, Cr, Cd, A, Rho, v)
% g: gravitational force constant
% v: velocity
% t: cycling time
% W: total weight (rider+bike)
% C_r: coefficient of rolling resistance
% C_d: drag coeficient
% A: frontal surface area (m2)
% Rho: air density (kg/m3)

% Gravity Force // Force for Climbing
f_g = g .* W .* sin(atan(G/100));

% Rolling Force // Rolling Resistance Force
f_r = g .* W .* Cr .* cos(atan(G/100));

% Aerodynamic Drag // Air Resistance Force
f_d = 0.5 .* Cd .* A .* Rho .* v^2;

end

