function [A,D]=extdinamicas(sig,nivel,tipo)

D=[];
[C,L] = wavedec(sig,nivel,tipo);
A = wrcoef('a',C,L,tipo,nivel);

%[P,F]=periodogram(A,hanning(length(A)),length(A),fs);
%subplot(nivel+1,1,1), plot(F,P)

for k=1:nivel
    D(:,k)=wrcoef('d',C,L,tipo,k);
    %[P,F]=periodogram(D(:,k),hanning(D(:,k)),length(D(:,k)),fs);
    %subplot(nivel+1,1,k+1), plot(F,P)
end