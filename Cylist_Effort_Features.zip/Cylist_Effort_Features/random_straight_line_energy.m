clear all;
close all;
clc;

% % Creat RL random straight lines
% RL = 500; %number of random lines
% for k0 = 1:RL
%         XX(k0,:) = randi ([1 256],1,2);
%         YY(k0,:) = randi ([1 202],1,2);
% end
RL = 500; %number of random lines
load('XX.mat');
load('YY.mat');

%% Find RL lines in each image
% Read the image
input_folder = './IMG/';
inp_imageNames = dir(fullfile(input_folder, '*.jpg'));
inp_images = {inp_imageNames.name}';
total_images = length(inp_images);

iteration_start = 1;
iteration_end = 4;

for j = iteration_start:iteration_end
    inp = strcat('./IMG/', inp_images{j});  
    I = imread(inp);  
    I = double(rgb2gray(I));
    I2 = imresize(I,1/5);

% Compute the homogenized image
    [n,m] = size(I2);
    nivel = 7;

    for k = 1:n
        x = I2(k,:);
        [A,D] = extdinamicas(x,nivel,'db4');
        Iw(k,:) = sum(D');
    end

    for k = 1:m
        x = I2(:,k);
        [A,D] = extdinamicas(x,nivel,'db4');
        Iw2(:,k) = sum(D')';
    end
    
    Iout = Iw + Iw2;
%     figure, imagesc(Iout);

% Apply a midian filter on homogenized image
    I3 = medfilt2(I2,[5 5]);

% Find the coordinates and itesity values of each line in each image
    for k1 = 1:RL
        x1 = XX(k1,:);
        y1 = YY(k1,:);
        [cx1,cy1,c1] = improfile(I3,x1,y1);
        Coordinates{j,k1} = [cx1,cy1,c1];
    end
end
% Coordinates = Coordinates(~cellfun('isempty',results));

%% Compute the energy, power and work for RL path in each image
delta_pxl = 2; % distance (pixel)
delta_met = (2000.*delta_pxl)/256; % the longest path in Tou de France is 2000 meters.
g = 9.8067; % gravitational force constant (m/s^2)
m = 80; % total weight (bike+biker) (kg)
Cr = 0.005; % coefficient of rolling resistance
Cd = 0.63; % drag coeficientc
Af = 0.6; % frontal surface area (m^2)
Rho = 1.225; % air density (kg/m^3)
v = 11; % velocity (m/s) // in Tou de France the average speed is 25 miles per hour or 40 km per hour.

for k2 = iteration_start:iteration_end
    for k3 = 1:RL
        y_path = Coordinates{k2,k3}(:,3);
        len_y_path = length (y_path);
        x_path = [1:len_y_path]';
        
%         if len_y_path >= 20
            A = [x_path(1),y_path(1)];
            counter = 1;

            for k4 = 5:delta_pxl:len_y_path 
                B = [x_path(k4),y_path(k4)];
                % Calculate the distance between A and B
                AB_pxl(counter,:) = sqrt (abs(B(1,2) - A(1,2) + B(1,1) - A(1,1)));
                AB_met(counter,:) = (2000.*AB_pxl(counter,:))/256;
                % Calculate the time to pass from A to B
                t(counter,:) = AB_met (counter,:) / v;
                % Calculate the delta or height from A to B
                h_pxl(counter,:) =  abs(B(1,2)-A(1,2));
                h_met(counter,:) = (2000.*h_pxl(counter,:))/256;
                % Calculate the Slope G from A to B
                G(counter,:) = (h_met(counter,:)/delta_met) .* 100;
                GG = G(counter,:);
                % Calculate the Gravitational Frce, Rolling Force and Drag Force and Total Force from A to B
                [fg, fr, fd] = biking(g, GG, m, Cr, Cd, Af, Rho, v);
                F(counter,:) = fg + fr + fd; % Total force
                % Calculate Work, Energy and Power from A to B
                W(counter,:) = F(counter,:) .* AB_met(counter,:); % Work (Joules)
                E(counter,:) = F(counter,:) .* v .* t(counter,:); % Energy per t (Joules)
                P(counter,:) = F(counter,:) .* v; % Driving Power (Watts)

                A = B;
                counter = counter +1; 
            end
            
            results{k2,k3} = [F,W,E,P];
            clear x_path y_path AB_pxl AB_met h_pxl h_met G F W E P;
%         end 
    end 
end

for k5 = iteration_start:iteration_end
    for k6 = 1:RL
        F_mean (k5,k6) = ceil(mean(results{k5,k6}(:,1)));
        W_mean (k5,k6) = ceil(mean(results{k5,k6}(:,2)));
        E_mean(k5,k6) = ceil(mean(results{k5,k6}(:,3)));
        P_mean (k5,k6) = ceil(mean(results{k5,k6}(:,4)));
    end
end
for k7= iteration_start:iteration_end
    features (k7,1) = mean (E_mean(k7,:));
    features (k7,2) = mean (P_mean(k7,:));
%     features (k7,3) = mean (F_sum(k7,:));
    
end

% figure,
% plot3(F_avg(1,:), E_avg(1,:), P_avg(1,:),'r*', 'markers', 10),hold on,
% plot3(F_avg(2,:), E_avg(2,:), P_avg(2,:),'g*', 'markers', 10),hold on,
% plot3(F_avg(3,:), E_avg(3,:), P_avg(3,:),'b*', 'markers', 10),hold off,
% xlabel('Totla Force'); ylabel('Energy'); zlabel('Power');
% legend ('Order','Disorder','Very Disorder');
  