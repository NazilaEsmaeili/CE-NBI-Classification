
clear all;
%close all;
clc;

disp ('This program is designed to automatically characterize the vascular patterns in CE + NBI images.');
disp ('In this program, user can select one image from the folder "Image"');
disp ('The algorithm will pre-process the image and compute 5 indicators: ind_HGD, ind_RIA, ind_ANG, indi_DIS and ind_CUR.');
disp ('24 features extracted from these indicators are available in the matrix "Featute_set".');
disp ('At the end, the pre-processed image and five indicators of the selceted image will be shown.');
disp ('Please press "Enter" to continue:');
pause;

%% Read the image
[filename, pathname] = uigetfile('*.jpg','Select An Image');
inputimage = strcat(pathname, filename);

I = imread(inputimage);
I = double(rgb2gray(I));
I2 = imresize(I,1/5);

%% Image pre-processing
% Compute the homogenized image

[n,m] = size(I2);
nivel = 7;

for k = 1:n
    x = I2(k,:);
    [A,D] = extdinamicas(x,nivel,'db4');
    Iw(k,:) = sum(D');
end

for k = 1:m
    x = I2(:,k);
    [A,D] = extdinamicas(x,nivel,'db4');
    Iw2(:,k) = sum(D')';
end
    
Iout = Iw + Iw2;

% Compute the Frangi filter of the homogenized image
[If,Im] = main(Iout);
    
% Binarized the image
level = graythresh(If);
I3 = im2bw (If, level*0.4);

% Image skeletonization 
S = bwmorph (I3, 'skel', Inf);

  
%% Indicator and feature computation
tic;
% Histogram of gradient direction
[ind_HGD, F_HGD] = HGD(Iout);
    
% Rotational image averaging
[ind_RIA, F_RIA] = RIA (If);
    
% Angle & Distance
[ind_ANG, ind_DIS, F_ANG_DIS] = AngDis(S);
    
% Curvature
[ind_CUR, F_CUR] = CURVE(S);
    
% Feature set
Feature_set = [F_HGD, F_RIA, F_ANG_DIS, F_CUR];

% Plot the pre-processed images and five indicators
figure (),
subplot (2,4,1), imagesc (Iout), set(gca,'xtick',[]), set(gca,'ytick',[]), title ('Homogenized Image');
subplot (2,4,2); imagesc (If), set(gca,'xtick',[]), set(gca,'ytick',[]), title ('Frangi Filter');
subplot (2,4,3); imshow (S), set(gca,'xtick',[]), set(gca,'ytick',[]),title ('Skeletonization');

subplot (2,4,4); hist (ind_HGD, 1000),  title ('Histogram of Gradient Direction'), ylim ([0 100]), set(gca,'xtick',[]);
subplot (2,4,5); plot (ind_RIA), title ('Rotational Image Averaging'), ylim ([0 3.5*10^-17]), set(gca,'xtick',[]);
subplot (2,4,6); plot (ind_ANG), title ('Angle'), ylim ([0 1.6]), set(gca,'xtick',[]);
subplot (2,4,7); plot (ind_DIS), title ('Distance'), ylim ([0 350]), set(gca,'xtick',[]);
subplot (2,4,8); plot (ind_CUR), title ('Curvature');  ylim ([0 0.45]), set(gca,'xtick',[]);

cputime
toc;